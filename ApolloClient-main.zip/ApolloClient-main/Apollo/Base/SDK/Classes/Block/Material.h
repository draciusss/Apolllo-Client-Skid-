#pragma once

class Material
{
public:
	MaterialType type; //0x0000
	//bool isReplacable; //0x0005 
};
