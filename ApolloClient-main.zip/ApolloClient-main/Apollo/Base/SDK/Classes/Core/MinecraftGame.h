#pragma once

class MinecraftGame
{
public:
	// 0x1A8 1.20.61
	// 0x190 1.20.51
	// 0x108 1.20.0.1
	BUILD_ACCESS(bool, CanUseKeys, 0x1A8); // 1.21.2
};