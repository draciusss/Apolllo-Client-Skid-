#pragma once

class NetworkBlockPosition {
public:
    Vector3<float> position;
};