#pragma once

struct ActorGameTypeComponent
{
	GameType gametype;
};