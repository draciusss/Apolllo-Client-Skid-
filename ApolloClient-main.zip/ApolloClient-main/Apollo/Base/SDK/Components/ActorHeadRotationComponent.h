#pragma once

struct ActorHeadRotationComponent {
    Vector2<float> rotation;
};