#pragma once

struct ActorTypeComponent
{
	int32_t type;
};