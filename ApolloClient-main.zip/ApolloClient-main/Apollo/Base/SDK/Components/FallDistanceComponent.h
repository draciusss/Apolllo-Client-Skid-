#pragma once

struct FallDistanceComponent
{
	float fallDistance;
};