#pragma once

struct MobBodyRotationComponent {
    float bodyRot;
    float prevBodyRot;
};