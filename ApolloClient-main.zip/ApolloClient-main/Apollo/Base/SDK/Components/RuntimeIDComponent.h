#pragma once

struct RuntimeIDComponent {
    int64_t runtimeID;
};